# HandyCT 2.0
专业的临床研究数据转换工具，支持 CDISC 标准（SDTM/ADaM/Define-XML）。
基于历史权威资产重构，专注于 FDA 合规性数据审计。
HandyCT 2.0 Initial Deploy 
