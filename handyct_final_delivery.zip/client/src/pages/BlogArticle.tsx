import { useState, useMemo } from 'react';
import { useRoute, Link } from 'wouter';
import { useTranslation } from 'react-i18next';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import rehypeRaw from 'rehype-raw';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, Calendar, Clock, BookOpen } from 'lucide-react';
import { getBlogArticleBySlug, getRelatedArticles } from '@/lib/blog-data';
import LanguageSwitcher from '@/components/LanguageSwitcher';

export default function BlogArticle() {
  const [match, params] = useRoute('/blog/:slug');
  const { i18n, t } = useTranslation();
  const article = match ? getBlogArticleBySlug(params?.slug) : null;
  const relatedArticles = article ? getRelatedArticles(article.slug) : [];
  const [showTOC, setShowTOC] = useState(false);

  // 获取当前语言的内容
  const currentContent = i18n.language === 'en' ? (article?.contentEn || article?.content) : article?.content;
  const currentTitle = i18n.language === 'en' ? (article?.titleEn || article?.title) : article?.title;
  const currentDescription = i18n.language === 'en' ? (article?.descriptionEn || article?.description) : article?.description;

  if (!article) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
        <header className="sticky top-0 z-50 border-b border-slate-200 bg-white shadow-sm">
          <div className="container flex h-16 items-center justify-between">
            <a href="/blog" className="no-underline">
              <Button variant="ghost" size="sm" className="flex items-center gap-2">
                <ArrowLeft className="h-4 w-4" />
                {t('blog.backToBlog')}
              </Button>
            </a>
            <LanguageSwitcher />
          </div>
        </header>
        <main className="container py-12">
          <div className="text-center">
            <h1 className="mb-4 text-2xl font-bold text-slate-900">{t('blog.notFound')}</h1>
            <a href="/blog" className="no-underline">
              <Button className="bg-emerald-600 hover:bg-emerald-700">
                {t('blog.returnToBlog')}
              </Button>
            </a>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* 顶部导航 */}
      <header className="sticky top-0 z-50 border-b border-slate-200 bg-white shadow-sm">
        <div className="container flex h-16 items-center justify-between">
          <a href="/blog" className="no-underline">
            <Button variant="ghost" size="sm" className="flex items-center gap-2">
              <ArrowLeft className="h-4 w-4" />
              {t('blog.backToBlog')}
            </Button>
          </a>
          <LanguageSwitcher />
        </div>
      </header>

      <main className="container py-12">
        <div className="grid gap-8 lg:grid-cols-4">
          {/* 浮动目录（大屏幕固定） */}
          <aside className="hidden lg:block lg:col-span-1">
            <div className="sticky top-20 rounded-lg border border-slate-200 bg-white p-4 shadow-sm">
              <h3 className="mb-4 font-semibold text-slate-900">{t('blog.tableOfContents')}</h3>
              <nav className="space-y-2 text-sm">
                <p className="text-slate-500">{t('blog.tableOfContents')}</p>
              </nav>
            </div>
          </aside>

          {/* 主要内容 */}
          <div className="lg:col-span-3">
            {/* 文章头部 */}
            <article className="rounded-lg border border-slate-200 bg-white p-8 shadow-sm">
              {/* 元信息 */}
              <div className="mb-6 border-b border-slate-200 pb-6">
                <div className="mb-4 flex flex-wrap gap-2">
                  <Badge variant="secondary">{article.category}</Badge>
                  {article.tags.map((tag) => (
                    <Badge key={tag} variant="outline">
                      {tag}
                    </Badge>
                  ))}
                </div>

                <h1 className="mb-4 text-4xl font-bold text-slate-900">{currentTitle}</h1>
                <p className="mb-4 text-lg text-slate-600">{currentDescription}</p>

                <div className="flex flex-wrap gap-6 text-sm text-slate-600">
                  <div className="flex items-center gap-2">
                    <Calendar className="h-4 w-4" />
                    <span>{new Date(article.publishedDate).toLocaleDateString()}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4" />
                    <span>{article.readingTime} {t('blog.readingTime')}</span>
                  </div>
                  <div className="text-slate-500">
                    {t('blog.author')}: {article.author}
                  </div>
                </div>
              </div>

              {/* Markdown 内容 - 使用 prose 排版 */}
              <div className="prose prose-slate lg:prose-xl mx-auto max-w-none">
                <ReactMarkdown
                  remarkPlugins={[remarkGfm]}
                  rehypePlugins={[rehypeRaw]}
                  components={{
                    h1: ({ node, ...props }: any) => (
                      <h1 className="text-3xl font-bold mt-8 mb-4 text-slate-900" {...props} />
                    ),
                    h2: ({ node, ...props }: any) => (
                      <h2 className="text-2xl font-bold mt-6 mb-3 text-slate-900" {...props} />
                    ),
                    h3: ({ node, ...props }: any) => (
                      <h3 className="text-xl font-semibold mt-4 mb-2 text-slate-900" {...props} />
                    ),
                    p: ({ node, ...props }: any) => (
                      <p className="text-slate-700 leading-relaxed mb-4" {...props} />
                    ),
                    ul: ({ node, ...props }: any) => (
                      <ul className="list-disc list-inside mb-4 space-y-2 text-slate-700" {...props} />
                    ),
                    ol: ({ node, ...props }: any) => (
                      <ol className="list-decimal list-inside mb-4 space-y-2 text-slate-700" {...props} />
                    ),
                    li: ({ node, ...props }: any) => (
                      <li className="text-slate-700" {...props} />
                    ),
                    blockquote: ({ node, ...props }: any) => (
                      <blockquote className="border-l-4 border-emerald-500 bg-emerald-50 p-4 my-4 italic text-slate-700" {...props} />
                    ),
                    code: ({ node, inline, ...props }: any) =>
                      inline ? (
                        <code className="bg-slate-100 px-2 py-1 rounded text-sm font-mono text-slate-900" {...props} />
                      ) : (
                        <pre className="bg-slate-900 text-slate-100 p-4 rounded-lg overflow-x-auto my-4">
                          <code className="font-mono text-sm" {...props} />
                        </pre>
                      ),
                    table: ({ node, ...props }: any) => (
                      <table className="w-full border-collapse border border-slate-300 my-4" {...props} />
                    ),
                    th: ({ node, ...props }: any) => (
                      <th className="border border-slate-300 bg-slate-100 p-2 text-left font-semibold" {...props} />
                    ),
                    td: ({ node, ...props }: any) => (
                      <td className="border border-slate-300 p-2" {...props} />
                    ),
                    a: ({ node, ...props }: any) => (
                      <a className="text-emerald-600 hover:text-emerald-700 underline" {...props} />
                    ),
                  }}
                >
                  {currentContent || ''}
                </ReactMarkdown>
              </div>

              {/* 转化按钮 */}
              <div className="mt-12 border-t border-slate-200 pt-8">
                <div className="rounded-lg bg-emerald-50 p-6">
                  <h3 className="mb-2 text-lg font-semibold text-emerald-900">{t('blog.cta')}</h3>
                  <p className="mb-4 text-emerald-800">{t('blog.ctaDescription')}</p>
                  <a href="/" className="no-underline">
                    <Button className="bg-emerald-600 hover:bg-emerald-700">
                      <BookOpen className="mr-2 h-4 w-4" />
                      {t('blog.tryNow')}
                    </Button>
                  </a>
                </div>
              </div>

              {/* 关键词 */}
              <div className="mt-8 border-t border-slate-200 pt-6">
                <h4 className="mb-3 font-semibold text-slate-900">{t('blog.keywords')}</h4>
                <div className="flex flex-wrap gap-2">
                  {article.keywords.map((keyword) => (
                    <Badge key={keyword} variant="secondary">
                      {keyword}
                    </Badge>
                  ))}
                </div>
              </div>
            </article>

            {/* 相关文章 */}
            {relatedArticles.length > 0 && (
              <div className="mt-12">
                <h2 className="mb-6 text-2xl font-bold text-slate-900">{t('blog.relatedArticles')}</h2>
                <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                  {relatedArticles.map((relArticle) => (
                    <a key={relArticle.slug} href={`/blog/${relArticle.slug}`} className="block no-underline">
                      <Card className="h-full transition-shadow hover:shadow-lg cursor-pointer">
                        <CardHeader>
                          <div className="mb-2 flex gap-2">
                            <Badge variant="secondary">{relArticle.category}</Badge>
                          </div>
                          <CardTitle className="line-clamp-2 text-lg">
                            {i18n.language === 'en' ? (relArticle.titleEn || relArticle.title) : relArticle.title}
                          </CardTitle>
                        </CardHeader>
                        <CardContent>
                          <p className="mb-4 line-clamp-3 text-sm text-slate-600">
                            {i18n.language === 'en' ? (relArticle.descriptionEn || relArticle.description) : relArticle.description}
                          </p>
                          <div className="flex items-center gap-4 text-xs text-slate-500">
                            <span className="flex items-center gap-1">
                              <Clock className="h-3 w-3" />
                              {relArticle.readingTime} {t('blog.readingTime')}
                            </span>
                          </div>
                        </CardContent>
                      </Card>
                    </a>
                  ))}
                </div>
              </div>
            )}

            {/* 返回按钮 */}
            <div className="mt-12">
              <a href="/" className="no-underline">
                <Button variant="outline" className="w-full">
                  {t('blog.backToTools')}
                </Button>
              </a>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
